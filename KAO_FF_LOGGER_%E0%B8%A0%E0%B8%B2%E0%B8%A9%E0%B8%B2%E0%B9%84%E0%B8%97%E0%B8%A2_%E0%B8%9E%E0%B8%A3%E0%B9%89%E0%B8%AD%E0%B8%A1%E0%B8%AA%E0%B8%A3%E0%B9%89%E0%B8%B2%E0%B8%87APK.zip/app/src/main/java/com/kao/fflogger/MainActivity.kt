package com.kao.fflogger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF090711)
private val Panel = Color(0xFF171126)
private val Purple = Color(0xFF9B5CFF)
private val Muted = Color(0xFFB9AACF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KAOApp() }
    }
}

@Composable
fun KAOApp() {
    var tab by remember { mutableStateOf("หน้าหลัก") }
    var recording by remember { mutableStateOf(false) }
    var macroName by remember { mutableStateOf("ชุดคำสั่งของฉัน") }
    var code by remember { mutableStateOf("// ตัวอย่างคำสั่งสำหรับแอปทดสอบเท่านั้น\nlog(\"เริ่มชุดคำสั่ง\")\nwait(500)\nlog(\"ทำงานเสร็จ\")") }
    var logs by remember { mutableStateOf(listOf("KAO LOGGER พร้อมใช้งาน")) }
    var profiles by remember { mutableStateOf(listOf("ชุดคำสั่งของฉัน")) }

    fun addLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logs = listOf("[$time] $message") + logs
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Bg, surface = Panel,
        onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
            Text("KAO  /  บันทึกการทำงาน", color = Purple, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("พื้นที่ทำงาน • โหมดทดสอบในเครื่อง", color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("หน้าหลัก", "บันทึก", "แก้ไขโค้ด", "ประวัติ").forEach {
                    FilterChip(selected = tab == it, onClick = { tab = it }, label = { Text(it) })
                }
            }
            Spacer(Modifier.height(16.dp))
            when (tab) {
                "หน้าหลัก" -> {
                    CardBlock("สถานะระบบ") {
                        Text(if (recording) "● กำลังบันทึกเหตุการณ์ในแอปนี้" else "● พร้อมใช้งาน", color = if (recording) Purple else Muted)
                        Spacer(Modifier.height(8.dp))
                        Text("โหมดปลอดภัย: บันทึกเฉพาะการกดปุ่มภายในแอป KAO LOGGER", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    CardBlock("ชุดคำสั่ง") {
                        Text("ชุดคำสั่งที่เลือก: $macroName", color = Color.White)
                        Text("มีทั้งหมด ${profiles.size} ชุด", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { addLog("ทดสอบปุ่มเรียกคำสั่งภายในแอป"); tab = "ประวัติ" }, modifier = Modifier.fillMaxWidth()) {
                        Text("ทดสอบปุ่มเรียกคำสั่ง")
                    }
                }
                "บันทึก" -> {
                    CardBlock("เครื่องบันทึกการทำงาน") {
                        OutlinedTextField(value = macroName, onValueChange = { macroName = it }, label = { Text("ชื่อชุดคำสั่ง") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = {
                            recording = !recording
                            addLog(if (recording) "เริ่มบันทึก: $macroName" else "หยุดบันทึก: $macroName")
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (recording) "หยุดบันทึก" else "เริ่มบันทึก")
                        }
                        Text("บันทึกการทำงานภายในแอปนี้เท่านั้น ไม่อ่านหรือควบคุม Free Fire", color = Muted, fontSize = 11.sp)
                    }
                }
                "แก้ไขโค้ด" -> {
                    CardBlock("ตัวแก้ไขโค้ด") {
                        OutlinedTextField(value = code, onValueChange = { code = it }, modifier = Modifier.fillMaxWidth().height(220.dp), label = { Text("แก้ไขข้อความคำสั่งตัวอย่าง") })
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { addLog("บันทึกข้อความโค้ดแล้ว"); tab = "ประวัติ" }, modifier = Modifier.fillMaxWidth()) { Text("บันทึกโค้ด") }
                        Text("โค้ดนี้เป็นข้อความตัวอย่าง ไม่ได้สั่งงานหรือควบคุมเกม", color = Muted, fontSize = 11.sp)
                    }
                }
                "ประวัติ" -> {
                    CardBlock("หน้าจอแสดงประวัติ") {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 420.dp)) {
                            items(logs) { Text(it, color = Color(0xFFD8C8FF), fontSize = 12.sp) }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { logs = listOf("ล้างประวัติแล้ว") }) { Text("ล้างประวัติ") }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Text("KAO FF LOGGER • แอปต้นแบบ • ไม่เชื่อมต่อหรือแก้ไขเกม", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun CardBlock(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Purple, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}
