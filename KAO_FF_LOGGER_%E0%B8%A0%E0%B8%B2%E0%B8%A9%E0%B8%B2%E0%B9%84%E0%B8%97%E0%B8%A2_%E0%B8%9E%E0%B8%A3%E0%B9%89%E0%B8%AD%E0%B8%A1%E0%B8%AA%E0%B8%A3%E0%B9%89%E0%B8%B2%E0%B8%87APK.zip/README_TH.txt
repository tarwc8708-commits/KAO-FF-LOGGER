KAO FF LOGGER — โปรเจกต์ Android ภาษาไทย

วิธีสร้าง APK:
1. เปิดโฟลเดอร์นี้ด้วย Android Studio
2. รอ Gradle Sync ให้เสร็จ
3. เลือกเมนู Build > Build Bundle(s) / APK(s) > Build APK(s)
4. เมื่อสร้างสำเร็จ Android Studio จะแสดงปุ่ม Locate เพื่อเปิดไฟล์ APK

หรือใช้ GitHub Actions:
1. สร้าง repository ใหม่บน GitHub แล้วอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้
2. เปิดแท็บ Actions แล้วเลือกเวิร์กโฟลว์ "สร้างไฟล์ APK"
3. กด Run workflow
4. ดาวน์โหลด Artifact ชื่อ KAO-FF-LOGGER-APK เมื่อทำงานสำเร็จ

ฟีเจอร์: หน้าแรก, เครื่องบันทึกเหตุการณ์ภายในแอป, ตัวแก้ไขข้อความโค้ด, ประวัติ/Console
ข้อจำกัด: เป็นแอปต้นแบบ ไม่อ่านหน่วยความจำเกม ไม่ฉีดโค้ด และไม่ควบคุมการยิงใน Free Fire
